package com.curso.alumna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlumnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlumnaApplication.class, args);
	}

}

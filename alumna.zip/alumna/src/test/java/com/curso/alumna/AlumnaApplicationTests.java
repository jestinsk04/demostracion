package com.curso.alumna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlumnaApplicationTests {

	@Test
	void contextLoads() {
	}

}
